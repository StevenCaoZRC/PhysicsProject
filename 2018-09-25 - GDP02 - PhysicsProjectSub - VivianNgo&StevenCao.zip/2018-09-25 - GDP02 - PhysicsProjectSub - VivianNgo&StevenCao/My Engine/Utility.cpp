//
// Bachelor of Software Engineering
// Media Design School
// Auckland
// New Zealand
//
// (c) 2005 - 2018 Media Design School
//
// File Name	:	Utility.cpp
// Description	:	main implementation for Utility
// Author		:	Steven Cao & Vivian Ngo
// Mail 		:	steven.zha7447@mediadesign.school.nz, vivian.ngo7572@mediadesign.school.nz
//

// Library Includes //
#include <vector>
// Local Includes //
#include "Utility.h"
// Global Variables // 
GLuint CUtility::program;
CUtility::CUtility()
{

}

CUtility::~CUtility()
{}