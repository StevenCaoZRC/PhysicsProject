ReadMe - Apple time

Controls
	Tap on screen to jump
	
Instructions
	Avoid rocks and collect apples
	
	